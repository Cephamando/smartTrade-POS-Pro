/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: db    Database: pos_db
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `type` enum('food','drink','meal','ingredients','other') NOT NULL DEFAULT 'other',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Beverages',NULL,'drink'),
(2,'Meals',NULL,'food'),
(3,'Ingredients',NULL,'ingredients'),
(4,'Snacks',NULL,'food'),
(5,'Cleaning Material',NULL,'other');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(255) NOT NULL DEFAULT 'Expense',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grv_items`
--

DROP TABLE IF EXISTS `grv_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grv_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grv_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `grv_id` (`grv_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `grv_items_ibfk_1` FOREIGN KEY (`grv_id`) REFERENCES `grvs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grv_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grv_items`
--

LOCK TABLES `grv_items` WRITE;
/*!40000 ALTER TABLE `grv_items` DISABLE KEYS */;
INSERT INTO `grv_items` VALUES
(1,1,6,100.00,1200.00),
(2,2,8,100.00,0.00),
(3,3,9,10.00,0.00),
(4,4,3,10.00,1000.00);
/*!40000 ALTER TABLE `grv_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grvs`
--

DROP TABLE IF EXISTS `grvs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grvs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vendor_id` int NOT NULL,
  `location_id` int NOT NULL,
  `received_by` int NOT NULL,
  `total_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `reference_no` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `vendor_id` (`vendor_id`),
  KEY `location_id` (`location_id`),
  KEY `received_by` (`received_by`),
  CONSTRAINT `grvs_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`),
  CONSTRAINT `grvs_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `grvs_ibfk_3` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grvs`
--

LOCK TABLES `grvs` WRITE;
/*!40000 ALTER TABLE `grvs` DISABLE KEYS */;
INSERT INTO `grvs` VALUES
(1,2,1,1,120000.00,'','2026-02-07 06:45:07'),
(2,3,3,1,0.00,'','2026-02-07 08:32:38'),
(3,3,6,1,0.00,'','2026-02-07 08:59:27'),
(4,2,3,1,10000.00,'','2026-02-07 12:16:58');
/*!40000 ALTER TABLE `grvs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `location_id` int NOT NULL,
  `quantity` int DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_stock` (`product_id`,`location_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES
(1,1,3,886,'2026-02-09 06:30:43'),
(2,1,2,36,'2026-02-10 16:48:40'),
(3,2,3,495,'2026-02-07 11:59:39'),
(4,2,2,78,'2026-02-10 16:20:14'),
(5,3,1,14,'2026-02-10 00:32:45'),
(6,4,3,50,'2026-02-09 06:31:10'),
(7,4,2,6,'2026-02-10 16:47:24'),
(8,5,3,200,'2026-02-06 19:59:36'),
(9,5,2,11,'2026-02-10 16:48:49'),
(10,6,1,73,'2026-02-10 00:34:05'),
(11,7,3,50,'2026-02-06 19:59:36'),
(12,7,1,4,'2026-02-07 05:36:29'),
(13,1,1,388,'2026-02-09 22:57:29'),
(16,1,5,11,'2026-02-06 23:24:31'),
(20,3,5,20,'2026-02-07 07:07:36'),
(21,6,3,101,'2026-02-09 06:29:58'),
(22,8,3,100,'2026-02-07 08:32:39'),
(24,6,2,5,'2026-02-10 16:48:40'),
(25,9,6,5,'2026-02-07 09:00:33'),
(26,9,1,5,'2026-02-07 09:00:49'),
(27,3,3,75,'2026-02-09 07:25:12'),
(31,9,3,90,'2026-02-09 06:30:59');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_logs`
--

DROP TABLE IF EXISTS `inventory_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `location_id` int NOT NULL,
  `user_id` int NOT NULL,
  `change_qty` decimal(10,2) NOT NULL,
  `after_qty` decimal(10,2) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `reference_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_logs`
--

LOCK TABLES `inventory_logs` WRITE;
/*!40000 ALTER TABLE `inventory_logs` DISABLE KEYS */;
INSERT INTO `inventory_logs` VALUES
(1,3,1,1,-2.00,18.00,'sale',1,'2026-02-06 20:30:07'),
(2,6,1,1,-1.00,14.00,'sale',2,'2026-02-06 20:59:35'),
(3,6,1,1,-1.00,13.00,'sale',3,'2026-02-06 21:05:00'),
(4,1,1,1,200.00,200.00,'grv',NULL,'2026-02-06 21:12:02'),
(5,1,1,1,-10.00,190.00,'transfer_out',2,'2026-02-06 21:13:17'),
(6,1,1,1,110.00,300.00,'grv',NULL,'2026-02-06 21:14:10'),
(7,1,1,1,110.00,410.00,'grv',NULL,'2026-02-06 21:14:28'),
(8,1,5,1,10.00,10.00,'transfer_in',2,'2026-02-06 21:14:54'),
(9,4,3,1,-10.00,0.00,'transfer_out',3,'2026-02-06 21:15:42'),
(10,4,2,1,10.00,12.00,'transfer_in',3,'2026-02-06 21:15:45'),
(11,1,5,1,-2.00,8.00,'sale',4,'2026-02-06 21:18:11'),
(12,1,5,1,-1.00,7.00,'sale',4,'2026-02-06 21:33:10'),
(13,1,5,1,-1.00,6.00,'sale',4,'2026-02-06 21:42:35'),
(14,1,5,1,-1.00,5.00,'sale',4,'2026-02-06 22:44:17'),
(15,1,5,1,-3.00,2.00,'sale',5,'2026-02-06 23:13:04'),
(16,1,5,1,-1.00,1.00,'sale',6,'2026-02-06 23:15:54'),
(17,1,3,1,-10.00,990.00,'transfer_out',4,'2026-02-06 23:24:29'),
(18,1,5,1,10.00,11.00,'transfer_in',4,'2026-02-06 23:24:31'),
(19,7,1,1,-1.00,4.00,'sale',7,'2026-02-07 05:36:29'),
(20,1,1,1,-1.00,409.00,'sale',8,'2026-02-07 05:36:55'),
(21,6,1,1,-1.00,12.00,'sale',9,'2026-02-07 05:37:53'),
(22,6,1,1,100.00,112.00,'grv',1,'2026-02-07 06:45:07'),
(23,6,1,1,-1.00,111.00,'sale',10,'2026-02-07 07:08:27'),
(24,6,3,1,100.00,100.00,'grv',NULL,'2026-02-07 08:16:48'),
(25,1,3,1,-1.00,989.00,'sale',11,'2026-02-07 08:18:05'),
(26,1,3,1,-1.00,988.00,'sale',11,'2026-02-07 08:18:39'),
(27,2,3,1,-1.00,499.00,'sale',12,'2026-02-07 08:19:45'),
(28,1,3,1,-1.00,987.00,'sale',12,'2026-02-07 08:19:45'),
(29,6,3,1,-1.00,99.00,'sale',13,'2026-02-07 08:20:07'),
(30,6,3,1,-1.00,98.00,'sale',13,'2026-02-07 08:21:05'),
(31,2,3,1,-1.00,498.00,'sale',14,'2026-02-07 08:22:06'),
(32,2,3,1,-1.00,497.00,'sale',15,'2026-02-07 08:22:44'),
(33,8,3,1,100.00,100.00,'grv',2,'2026-02-07 08:32:39'),
(34,6,1,1,-10.00,101.00,'transfer_out',6,'2026-02-07 08:54:14'),
(35,6,2,1,10.00,10.00,'transfer_in',6,'2026-02-07 08:54:26'),
(36,9,6,1,10.00,10.00,'grv',3,'2026-02-07 08:59:28'),
(37,9,6,1,-5.00,5.00,'transfer_out',7,'2026-02-07 09:00:33'),
(38,9,1,1,5.00,5.00,'transfer_in',7,'2026-02-07 09:00:49'),
(39,6,3,1,-1.00,97.00,'sale',16,'2026-02-07 11:53:20'),
(40,2,3,1,-2.00,495.00,'sale',14,'2026-02-07 11:59:39'),
(41,1,3,1,-1.00,986.00,'sale',16,'2026-02-07 12:01:49'),
(42,6,3,1,-1.00,96.00,'sale',17,'2026-02-07 12:04:46'),
(43,3,3,1,10.00,10.00,'grv',4,'2026-02-07 12:16:58'),
(44,3,3,1,-5.00,5.00,'transfer_out',8,'2026-02-07 12:18:52'),
(45,3,1,1,5.00,13.00,'transfer_in',8,'2026-02-07 12:19:28'),
(46,6,3,1,5.00,101.00,'grv',NULL,'2026-02-09 06:29:58'),
(47,1,3,1,-100.00,886.00,'adjustment',NULL,'2026-02-09 06:30:43'),
(48,9,3,1,90.00,90.00,'grv',NULL,'2026-02-09 06:30:59'),
(49,4,3,1,50.00,50.00,'grv',NULL,'2026-02-09 06:31:10'),
(50,3,3,1,80.00,85.00,'grv',NULL,'2026-02-09 06:31:17'),
(51,3,3,1,-10.00,75.00,'transfer_out',9,'2026-02-09 07:25:12'),
(52,3,1,1,10.00,23.00,'transfer_in',9,'2026-02-09 07:25:24'),
(53,1,1,1,-1.00,408.00,'sale',21,'2026-02-09 08:04:34'),
(54,6,1,1,-1.00,100.00,'sale',21,'2026-02-09 08:04:34'),
(55,1,1,1,-1.00,407.00,'sale',22,'2026-02-09 19:18:24'),
(56,6,1,1,-1.00,99.00,'sale',23,'2026-02-09 19:32:15'),
(57,1,1,1,-1.00,406.00,'sale',21,'2026-02-09 19:32:41'),
(58,6,1,1,-1.00,98.00,'sale',21,'2026-02-09 19:32:41'),
(59,1,1,1,-1.00,405.00,'sale',24,'2026-02-09 19:52:37'),
(60,6,1,1,-1.00,97.00,'sale',24,'2026-02-09 19:52:37'),
(61,1,1,1,-1.00,404.00,'sale',25,'2026-02-09 19:52:38'),
(62,6,1,1,-1.00,96.00,'sale',26,'2026-02-09 19:52:38'),
(63,1,1,1,-1.00,403.00,'sale',27,'2026-02-09 19:54:42'),
(64,3,1,1,-1.00,22.00,'sale',27,'2026-02-09 19:54:42'),
(65,1,1,1,-1.00,402.00,'sale',28,'2026-02-09 19:54:42'),
(66,6,1,1,-1.00,95.00,'sale',28,'2026-02-09 19:54:42'),
(67,1,1,1,-1.00,401.00,'sale',29,'2026-02-09 19:54:42'),
(68,6,1,1,-1.00,94.00,'sale',29,'2026-02-09 19:54:42'),
(69,1,1,1,-1.00,400.00,'sale',30,'2026-02-09 20:08:34'),
(70,3,1,1,-1.00,21.00,'sale',30,'2026-02-09 20:08:34'),
(71,1,1,1,-1.00,399.00,'sale',31,'2026-02-09 20:08:34'),
(72,6,1,1,-1.00,93.00,'sale',31,'2026-02-09 20:08:34'),
(73,1,1,1,-1.00,398.00,'sale',32,'2026-02-09 20:08:34'),
(74,3,1,1,-1.00,20.00,'sale',32,'2026-02-09 20:08:34'),
(75,6,1,1,-1.00,92.00,'sale',33,'2026-02-09 20:10:04'),
(76,6,1,1,-1.00,91.00,'sale',33,'2026-02-09 20:18:44'),
(77,6,1,1,-1.00,90.00,'sale',35,'2026-02-09 20:19:42'),
(78,6,1,1,-1.00,89.00,'sale',35,'2026-02-09 20:22:14'),
(79,1,1,1,-1.00,397.00,'sale',47,'2026-02-09 21:10:17'),
(80,1,1,1,-2.00,395.00,'sale',48,'2026-02-09 21:10:17'),
(81,1,1,1,-1.00,394.00,'sale',49,'2026-02-09 21:16:59'),
(82,6,1,1,-1.00,88.00,'sale',50,'2026-02-09 21:17:20'),
(83,6,1,1,-1.00,87.00,'sale',50,'2026-02-09 21:40:48'),
(84,1,1,1,-1.00,393.00,'sale',49,'2026-02-09 22:10:43'),
(85,1,1,1,-1.00,392.00,'sale',53,'2026-02-09 22:11:09'),
(86,6,1,1,-1.00,86.00,'sale',54,'2026-02-09 22:11:24'),
(87,1,1,1,-1.00,391.00,'sale',54,'2026-02-09 22:16:02'),
(88,6,1,1,-1.00,85.00,'sale',54,'2026-02-09 22:16:02'),
(89,1,1,1,-1.00,390.00,'sale',55,'2026-02-09 22:38:52'),
(90,1,1,1,-1.00,389.00,'sale',56,'2026-02-09 22:48:52'),
(91,6,1,1,-2.00,83.00,'sale',56,'2026-02-09 22:48:52'),
(92,1,1,1,-1.00,388.00,'sale',57,'2026-02-09 22:57:29'),
(93,6,1,1,-1.00,82.00,'sale',57,'2026-02-09 22:57:29'),
(94,3,1,1,-1.00,19.00,'sale',57,'2026-02-09 22:57:29'),
(95,6,1,1,-1.00,81.00,'sale',58,'2026-02-09 22:58:01'),
(96,3,1,1,-1.00,18.00,'sale',59,'2026-02-09 22:58:48'),
(97,6,1,1,-1.00,80.00,'sale',60,'2026-02-09 23:27:07'),
(98,6,1,1,-2.00,78.00,'sale',61,'2026-02-09 23:27:47'),
(99,6,1,1,-1.00,77.00,'sale',60,'2026-02-09 23:29:29'),
(100,6,1,1,-1.00,76.00,'sale',60,'2026-02-09 23:29:45'),
(101,6,1,1,-1.00,75.00,'sale',62,'2026-02-09 23:35:29'),
(102,6,1,1,-1.00,74.00,'sale',62,'2026-02-09 23:36:42'),
(103,6,1,1,-1.00,73.00,'sale',62,'2026-02-09 23:36:59'),
(104,6,1,1,-1.00,72.00,'sale',62,'2026-02-09 23:37:22'),
(105,6,1,1,-1.00,71.00,'sale',62,'2026-02-09 23:37:31'),
(106,6,1,1,-1.00,70.00,'sale',62,'2026-02-09 23:39:42'),
(107,3,1,1,-1.00,17.00,'sale',62,'2026-02-09 23:40:12'),
(108,3,1,1,-1.00,16.00,'sale',62,'2026-02-09 23:41:02'),
(109,3,1,1,-1.00,15.00,'sale',62,'2026-02-09 23:41:29'),
(110,3,1,1,1.00,16.00,'refund',62,'2026-02-10 00:03:42'),
(111,6,1,1,2.00,72.00,'refund',61,'2026-02-10 00:04:11'),
(112,3,1,1,-1.00,15.00,'sale',63,'2026-02-10 00:04:44'),
(113,3,1,1,-1.00,14.00,'sale',64,'2026-02-10 00:32:45'),
(114,6,1,1,1.00,73.00,'refund',60,'2026-02-10 00:34:05'),
(115,2,2,4,-1.00,99.00,'sale',65,'2026-02-10 10:32:02'),
(116,2,2,4,-1.00,98.00,'sale',65,'2026-02-10 10:32:38'),
(117,2,2,4,-1.00,97.00,'sale',66,'2026-02-10 10:33:12'),
(118,2,2,4,-4.00,93.00,'sale',67,'2026-02-10 10:33:27'),
(119,2,2,4,-4.00,89.00,'sale',67,'2026-02-10 10:33:46'),
(120,2,2,4,-1.00,88.00,'sale',68,'2026-02-10 10:34:14'),
(121,1,2,4,-1.00,49.00,'sale',68,'2026-02-10 10:34:14'),
(122,2,2,4,-1.00,87.00,'sale',68,'2026-02-10 10:36:36'),
(123,1,2,4,-1.00,48.00,'sale',68,'2026-02-10 10:36:36'),
(124,6,2,3,-1.00,9.00,'sale',68,'2026-02-10 12:16:23'),
(125,1,2,3,-1.00,47.00,'sale',68,'2026-02-10 12:16:23'),
(126,2,2,3,-1.00,86.00,'sale',69,'2026-02-10 12:17:42'),
(127,1,2,3,-1.00,46.00,'sale',69,'2026-02-10 12:17:42'),
(128,6,2,3,-1.00,8.00,'sale',69,'2026-02-10 12:17:42'),
(129,1,2,3,-1.00,45.00,'sale',70,'2026-02-10 12:28:00'),
(130,5,2,3,-2.00,18.00,'sale',70,'2026-02-10 12:28:25'),
(131,2,2,3,-2.00,84.00,'sale',70,'2026-02-10 12:28:48'),
(132,1,2,3,-3.00,42.00,'sale',71,'2026-02-10 12:33:10'),
(133,6,2,3,-1.00,7.00,'sale',71,'2026-02-10 12:33:10'),
(134,2,2,3,-1.00,83.00,'sale',71,'2026-02-10 12:33:10'),
(135,4,2,3,-1.00,11.00,'sale',72,'2026-02-10 12:39:35'),
(136,2,2,3,-1.00,82.00,'sale',73,'2026-02-10 13:08:41'),
(137,1,2,3,-1.00,41.00,'sale',73,'2026-02-10 13:08:41'),
(138,5,2,3,-1.00,17.00,'sale',73,'2026-02-10 13:08:41'),
(139,6,2,1,-1.00,6.00,'sale',74,'2026-02-10 16:11:57'),
(140,2,2,1,-1.00,81.00,'sale',74,'2026-02-10 16:11:57'),
(141,1,2,1,-1.00,40.00,'sale',75,'2026-02-10 16:20:14'),
(142,2,2,1,-3.00,78.00,'sale',75,'2026-02-10 16:20:14'),
(143,4,2,1,-1.00,10.00,'sale',76,'2026-02-10 16:27:06'),
(144,1,2,1,-1.00,39.00,'sale',76,'2026-02-10 16:27:06'),
(145,4,2,1,-1.00,9.00,'sale',76,'2026-02-10 16:27:55'),
(146,4,2,1,-1.00,8.00,'sale',76,'2026-02-10 16:28:28'),
(147,5,2,1,-1.00,16.00,'sale',77,'2026-02-10 16:35:33'),
(148,4,2,1,-1.00,7.00,'sale',77,'2026-02-10 16:35:33'),
(149,1,2,1,-1.00,38.00,'sale',78,'2026-02-10 16:37:41'),
(150,5,2,1,-3.00,13.00,'sale',79,'2026-02-10 16:46:19'),
(151,1,2,1,-1.00,37.00,'sale',79,'2026-02-10 16:47:24'),
(152,4,2,1,-1.00,6.00,'sale',79,'2026-02-10 16:47:24'),
(153,5,2,1,-1.00,12.00,'sale',80,'2026-02-10 16:48:40'),
(154,1,2,1,-1.00,36.00,'sale',80,'2026-02-10 16:48:40'),
(155,6,2,1,-1.00,5.00,'sale',80,'2026-02-10 16:48:40'),
(156,5,2,1,-1.00,11.00,'sale',80,'2026-02-10 16:48:49');
/*!40000 ALTER TABLE `inventory_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transfers`
--

DROP TABLE IF EXISTS `inventory_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `source_location_id` int NOT NULL,
  `dest_location_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `user_id` int NOT NULL,
  `status` enum('pending','in_transit','completed','cancelled') DEFAULT 'pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `dispatched_at` datetime DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transfers`
--

LOCK TABLES `inventory_transfers` WRITE;
/*!40000 ALTER TABLE `inventory_transfers` DISABLE KEYS */;
INSERT INTO `inventory_transfers` VALUES
(1,1,5,3,20.00,1,'completed','2026-02-06 23:10:32','2026-02-07 09:07:36',NULL),
(2,1,5,1,10.00,1,'completed','2026-02-06 23:10:51','2026-02-06 23:13:17','2026-02-06 23:14:54'),
(3,3,2,4,10.00,1,'completed','2026-02-06 23:15:34','2026-02-06 23:15:42','2026-02-06 23:15:45'),
(4,3,5,1,10.00,1,'completed','2026-02-07 01:20:30','2026-02-07 01:24:29','2026-02-07 01:24:31'),
(5,3,1,3,10.00,1,'completed','2026-02-07 09:08:40','2026-02-07 10:33:05',NULL),
(6,1,2,6,10.00,1,'completed','2026-02-07 10:53:56','2026-02-07 10:54:14','2026-02-07 10:54:26'),
(7,6,1,9,5.00,1,'completed','2026-02-07 11:00:08','2026-02-07 11:00:33','2026-02-07 11:00:49'),
(8,3,1,3,5.00,1,'completed','2026-02-07 14:14:23','2026-02-07 14:18:52','2026-02-07 14:19:28'),
(9,3,1,3,10.00,1,'completed','2026-02-09 09:24:52','2026-02-09 09:25:12','2026-02-09 09:25:24');
/*!40000 ALTER TABLE `inventory_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_stock`
--

DROP TABLE IF EXISTS `location_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_stock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `loc_prod_unique` (`location_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `location_stock_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `location_stock_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_stock`
--

LOCK TABLES `location_stock` WRITE;
/*!40000 ALTER TABLE `location_stock` DISABLE KEYS */;
INSERT INTO `location_stock` VALUES
(1,3,1,886.00),
(2,2,1,50.00),
(3,3,2,495.00),
(4,2,2,100.00),
(5,1,3,13.00),
(6,3,4,50.00),
(7,2,4,12.00),
(8,3,5,200.00),
(9,2,5,20.00),
(10,1,6,101.00),
(11,3,7,50.00),
(12,1,7,4.00),
(13,1,1,409.00),
(14,5,1,11.00),
(15,5,3,20.00),
(16,3,6,101.00),
(17,3,8,100.00),
(18,2,6,10.00),
(19,6,9,5.00),
(20,1,9,5.00),
(21,3,3,85.00),
(22,3,9,90.00);
/*!40000 ALTER TABLE `location_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` enum('store','kitchen','bar','warehouse') NOT NULL DEFAULT 'store',
  `can_sell` tinyint(1) DEFAULT '1',
  `can_receive_from_vendor` tinyint(1) DEFAULT '0',
  `address` text,
  `phone` varchar(50) DEFAULT '555-0000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES
(1,'Main Kitchen','kitchen',1,0,NULL,'555-0000'),
(2,'Main Bar','bar',1,0,NULL,'555-0000'),
(3,'Main Warehouse','warehouse',0,1,NULL,'555-0000'),
(4,'Restaurant Bar','bar',1,0,NULL,'555-0000'),
(5,'Coffee Shop','store',1,0,NULL,'555-0000'),
(6,'MIni Storeroom','warehouse',1,0,'','555-0000');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `points_balance` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES
(1,'John Doe','0977000000',NULL,50.00,'2026-02-06 19:59:36'),
(2,'Jane Smith','0966000000',NULL,120.00,'2026-02-06 19:59:36');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pickup_notifications`
--

DROP TABLE IF EXISTS `pickup_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pickup_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `status` enum('ready','collected') DEFAULT 'ready',
  `collected_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pickup_notifications`
--

LOCK TABLES `pickup_notifications` WRITE;
/*!40000 ALTER TABLE `pickup_notifications` DISABLE KEYS */;
INSERT INTO `pickup_notifications` VALUES
(1,1,'T-Bone Steak','collected',6,'2026-02-06 20:31:07'),
(2,2,'Beef Burger','collected',6,'2026-02-06 21:00:17'),
(3,3,'Beef Burger','collected',6,'2026-02-06 21:05:57'),
(4,4,'T-Bone Steak','collected',6,'2026-02-06 21:06:26'),
(5,9,'Beef Burger','collected',4,'2026-02-07 06:00:16'),
(6,10,'Beef Burger','collected',6,'2026-02-07 07:08:46'),
(7,13,'Beef Burger','collected',6,'2026-02-07 08:20:24'),
(8,13,'Beef Burger','collected',6,'2026-02-07 09:01:37'),
(9,16,'Beef Burger','collected',6,'2026-02-07 11:54:39'),
(10,17,'Beef Burger','collected',6,'2026-02-07 12:08:42'),
(11,21,'Beef Burger','collected',4,'2026-02-09 08:41:38'),
(12,23,'Beef Burger','collected',4,'2026-02-09 19:32:55'),
(13,21,'Beef Burger','collected',4,'2026-02-09 19:32:56'),
(14,24,'Beef Burger','collected',6,'2026-02-09 20:10:27'),
(15,26,'Beef Burger','collected',4,'2026-02-09 20:10:28'),
(16,27,'T-Bone Steak','collected',6,'2026-02-09 20:10:29'),
(17,28,'Beef Burger','collected',3,'2026-02-09 20:10:30'),
(18,29,'Beef Burger','collected',4,'2026-02-09 20:10:32'),
(19,30,'T-Bone Steak','collected',3,'2026-02-09 20:11:24'),
(20,31,'Beef Burger','collected',3,'2026-02-09 20:11:26'),
(21,32,'T-Bone Steak','collected',6,'2026-02-09 20:11:27'),
(22,33,'Beef Burger','collected',6,'2026-02-09 20:11:29'),
(23,33,'Beef Burger','collected',6,'2026-02-09 20:19:56'),
(24,35,'Beef Burger','collected',6,'2026-02-09 20:19:58'),
(25,35,'Beef Burger','collected',6,'2026-02-09 20:34:26'),
(26,50,'Beef Burger','collected',6,'2026-02-09 22:16:23'),
(27,54,'Beef Burger','collected',3,'2026-02-09 22:16:26'),
(28,56,'Beef Burger','collected',4,'2026-02-09 23:28:05'),
(29,61,'Beef Burger','collected',6,'2026-02-09 23:28:16'),
(30,57,'T-Bone Steak','collected',6,'2026-02-09 23:28:17'),
(31,57,'Beef Burger','collected',6,'2026-02-09 23:28:18'),
(32,58,'Beef Burger','collected',4,'2026-02-09 23:28:19'),
(33,59,'T-Bone Steak','collected',4,'2026-02-09 23:28:20'),
(34,60,'Beef Burger','collected',4,'2026-02-09 23:28:21'),
(35,60,'Beef Burger','collected',4,'2026-02-09 23:39:07'),
(36,62,'Beef Burger','collected',3,'2026-02-09 23:39:08'),
(37,62,'T-Bone Steak','collected',3,'2026-02-09 23:40:35'),
(38,62,'T-Bone Steak','collected',3,'2026-02-10 00:05:02'),
(39,63,'T-Bone Steak','collected',3,'2026-02-10 00:05:03'),
(40,64,'T-Bone Steak','collected',4,'2026-02-10 00:33:01');
/*!40000 ALTER TABLE `pickup_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `cost_price` decimal(10,2) DEFAULT '0.00',
  `unit` varchar(20) DEFAULT 'unit',
  `category_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `type` enum('item','service') DEFAULT 'item',
  `is_open_price` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'Coca Cola 300ml',NULL,15.00,8.00,'btl',1,1,'item',0),
(2,'Mosi Lager',NULL,25.00,12.00,'btl',1,1,'item',0),
(3,'T-Bone Steak',NULL,120.00,60.00,'plate',2,1,'item',0),
(4,'Jameson Shot',NULL,40.00,15.00,'tot',1,1,'item',0),
(5,'Water 500ml',NULL,5.00,2.00,'btl',1,1,'item',0),
(6,'Beef Burger',NULL,65.00,30.00,'plate',2,1,'item',0),
(7,'Cooking Oil',NULL,0.00,45.00,'ltr',3,1,'item',0),
(8,'Dish washer',NULL,0.00,0.00,'unit',5,1,'item',0),
(9,'Dish Wash',NULL,0.00,0.00,'unit',5,1,'item',0),
(10,'Free Delivery',NULL,0.00,0.00,'unit',NULL,0,'service',1),
(11,'Free Drink',NULL,0.00,0.00,'unit',NULL,0,'service',1),
(12,'Beef Burger',NULL,40.00,0.00,'unit',NULL,1,'service',1),
(13,'Split Balance',NULL,0.00,0.00,'unit',NULL,0,'service',1),
(14,'Delivery',NULL,30.00,0.00,'unit',NULL,1,'service',0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_requests`
--

DROP TABLE IF EXISTS `refund_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refund_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `requested_by_user_id` int NOT NULL,
  `reason` text,
  `refund_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `requested_by_user_id` (`requested_by_user_id`),
  CONSTRAINT `refund_requests_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `refund_requests_ibfk_2` FOREIGN KEY (`requested_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_requests`
--

LOCK TABLES `refund_requests` WRITE;
/*!40000 ALTER TABLE `refund_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `refund_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refunds`
--

DROP TABLE IF EXISTS `refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refunds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `manager_id` int NOT NULL,
  `amount_refunded` decimal(10,2) NOT NULL,
  `reason` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `manager_id` (`manager_id`),
  CONSTRAINT `refunds_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `refunds_ibfk_2` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refunds`
--

LOCK TABLES `refunds` WRITE;
/*!40000 ALTER TABLE `refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price_at_sale` decimal(10,2) NOT NULL,
  `cost_at_sale` decimal(10,2) DEFAULT '0.00',
  `status` enum('pending','cooking','ready','served') DEFAULT 'pending',
  `updated_at` timestamp NULL DEFAULT NULL,
  `fulfillment_status` enum('collected','uncollected') DEFAULT 'collected',
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES
(1,1,3,2,120.00,0.00,'ready',NULL,'collected'),
(2,2,6,1,65.00,0.00,'ready',NULL,'collected'),
(3,3,6,1,65.00,0.00,'ready',NULL,'collected'),
(8,4,1,1,15.00,0.00,'pending',NULL,'collected'),
(9,5,1,3,15.00,0.00,'pending',NULL,'collected'),
(10,6,1,1,15.00,0.00,'pending',NULL,'collected'),
(11,7,7,1,0.00,0.00,'pending',NULL,'collected'),
(12,8,1,1,15.00,0.00,'pending',NULL,'collected'),
(13,9,6,1,65.00,0.00,'ready',NULL,'collected'),
(14,10,6,1,65.00,0.00,'ready',NULL,'collected'),
(16,11,1,1,15.00,0.00,'pending',NULL,'collected'),
(17,12,2,1,25.00,0.00,'pending',NULL,'collected'),
(18,12,1,1,15.00,0.00,'pending',NULL,'collected'),
(20,13,6,1,65.00,0.00,'ready',NULL,'collected'),
(22,15,2,1,25.00,0.00,'pending',NULL,'collected'),
(24,14,2,2,25.00,0.00,'pending',NULL,'collected'),
(25,16,1,1,15.00,0.00,'pending',NULL,'collected'),
(26,17,6,1,65.00,0.00,'ready',NULL,'collected'),
(27,18,2,1,25.00,0.00,'pending',NULL,'collected'),
(32,22,1,1,15.00,0.00,'pending',NULL,'collected'),
(33,22,12,1,40.00,0.00,'pending',NULL,'collected'),
(34,23,6,1,65.00,0.00,'ready',NULL,'collected'),
(35,23,12,1,10.00,0.00,'pending',NULL,'collected'),
(36,21,1,1,15.00,0.00,'pending',NULL,'collected'),
(37,21,6,1,65.00,0.00,'ready',NULL,'collected'),
(38,24,1,1,15.00,0.00,'pending',NULL,'collected'),
(39,24,6,1,65.00,0.00,'ready',NULL,'collected'),
(40,25,1,1,15.00,0.00,'pending',NULL,'collected'),
(41,26,6,1,65.00,0.00,'ready',NULL,'collected'),
(42,27,1,1,15.00,0.00,'pending',NULL,'collected'),
(43,27,3,1,120.00,0.00,'ready',NULL,'collected'),
(44,28,1,1,15.00,0.00,'pending',NULL,'collected'),
(45,28,6,1,65.00,0.00,'ready',NULL,'collected'),
(46,29,1,1,15.00,0.00,'pending',NULL,'collected'),
(47,29,6,1,65.00,0.00,'ready',NULL,'collected'),
(48,30,1,1,15.00,0.00,'pending',NULL,'collected'),
(49,30,3,1,120.00,0.00,'ready',NULL,'collected'),
(50,31,1,1,15.00,0.00,'pending',NULL,'collected'),
(51,31,6,1,65.00,0.00,'ready',NULL,'collected'),
(52,32,1,1,15.00,0.00,'pending',NULL,'collected'),
(53,32,3,1,120.00,0.00,'ready',NULL,'collected'),
(55,33,6,1,65.00,0.00,'ready',NULL,'collected'),
(57,35,6,1,65.00,0.00,'ready',NULL,'collected'),
(63,44,13,1,22.50,0.00,'pending',NULL,'collected'),
(64,42,13,1,43.33,0.00,'pending',NULL,'collected'),
(65,39,13,1,32.50,0.00,'pending',NULL,'collected'),
(66,46,13,1,22.50,0.00,'pending',NULL,'collected'),
(67,47,1,1,15.00,0.00,'pending',NULL,'collected'),
(71,52,13,1,7.50,0.00,'pending',NULL,'collected'),
(72,50,6,1,65.00,0.00,'ready',NULL,'collected'),
(73,49,1,1,15.00,0.00,'pending',NULL,'collected'),
(76,54,1,1,15.00,0.00,'pending',NULL,'collected'),
(77,54,6,1,65.00,0.00,'ready',NULL,'collected'),
(78,55,1,1,15.00,0.00,'pending',NULL,'collected'),
(79,56,1,1,15.00,0.00,'pending',NULL,'collected'),
(80,56,6,2,65.00,0.00,'ready',NULL,'collected'),
(81,57,1,1,15.00,0.00,'pending',NULL,'collected'),
(82,57,6,1,65.00,0.00,'ready',NULL,'collected'),
(83,57,3,1,120.00,0.00,'ready',NULL,'collected'),
(84,58,6,1,65.00,0.00,'ready',NULL,'collected'),
(85,59,3,1,120.00,0.00,'ready',NULL,'collected'),
(87,61,6,2,65.00,0.00,'ready',NULL,'collected'),
(89,60,6,1,65.00,0.00,'ready',NULL,'collected'),
(98,62,3,1,120.00,0.00,'ready',NULL,'collected'),
(99,63,3,1,120.00,0.00,'ready',NULL,'collected'),
(100,64,3,1,120.00,0.00,'ready',NULL,'collected'),
(102,65,2,1,25.00,0.00,'pending',NULL,'collected'),
(115,69,2,1,25.00,0.00,'pending',NULL,'collected'),
(116,69,1,1,15.00,0.00,'pending',NULL,'collected'),
(117,69,6,1,65.00,0.00,'pending',NULL,'collected'),
(118,68,2,1,25.00,0.00,'pending',NULL,'collected'),
(119,68,1,1,15.00,0.00,'pending',NULL,'collected'),
(120,68,6,1,65.00,0.00,'pending',NULL,'collected'),
(121,67,2,4,25.00,0.00,'pending',NULL,'collected'),
(122,66,2,1,25.00,0.00,'pending',NULL,'collected'),
(126,70,1,1,15.00,0.00,'pending',NULL,'collected'),
(127,70,5,2,5.00,0.00,'pending',NULL,'collected'),
(128,70,2,2,25.00,0.00,'pending',NULL,'collected'),
(132,71,1,3,15.00,0.00,'pending',NULL,'collected'),
(133,71,6,1,65.00,0.00,'pending',NULL,'collected'),
(134,71,2,1,25.00,0.00,'pending',NULL,'collected'),
(136,72,4,1,40.00,0.00,'pending',NULL,'collected'),
(140,73,2,1,25.00,0.00,'pending',NULL,'collected'),
(141,73,1,1,15.00,0.00,'pending',NULL,'collected'),
(142,73,5,1,5.00,0.00,'pending',NULL,'collected'),
(145,74,6,1,65.00,0.00,'pending',NULL,'collected'),
(146,74,2,1,25.00,0.00,'pending',NULL,'collected'),
(149,75,1,1,15.00,0.00,'pending',NULL,'collected'),
(150,75,2,3,25.00,0.00,'pending',NULL,'collected'),
(155,76,1,1,15.00,0.00,'pending',NULL,'collected'),
(158,77,5,1,5.00,0.00,'pending',NULL,'collected'),
(159,77,4,1,40.00,0.00,'pending',NULL,'collected'),
(161,78,1,1,15.00,0.00,'pending',NULL,'collected'),
(165,79,5,3,5.00,0.00,'pending',NULL,'collected'),
(166,79,1,1,15.00,0.00,'pending',NULL,'collected'),
(167,79,4,1,40.00,0.00,'pending',NULL,'collected'),
(181,80,5,1,5.00,0.00,'pending',NULL,'collected'),
(182,80,1,1,15.00,0.00,'pending',NULL,'collected'),
(183,80,6,1,65.00,0.00,'pending',NULL,'collected');
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `user_id` int NOT NULL,
  `shift_id` int DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) DEFAULT '0.00',
  `total_tax` decimal(10,2) DEFAULT '0.00',
  `tip` decimal(10,2) DEFAULT '0.00',
  `final_total` decimal(10,2) DEFAULT '0.00',
  `payment_method` varchar(50) NOT NULL DEFAULT 'cash',
  `status` enum('completed','refund_requested','refunded','partially_refunded') DEFAULT 'completed',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `collected_by` varchar(100) DEFAULT NULL,
  `payment_status` enum('paid','pending','refunded') NOT NULL DEFAULT 'pending',
  `customer_name` varchar(100) DEFAULT 'Walk-in',
  `amount_tendered` decimal(10,2) DEFAULT '0.00',
  `change_due` decimal(10,2) DEFAULT '0.00',
  `member_id` int DEFAULT NULL,
  `points_earned` decimal(10,2) DEFAULT '0.00',
  `points_redeemed` decimal(10,2) DEFAULT '0.00',
  `split_group_id` varchar(50) DEFAULT NULL,
  `split_type` enum('none','item','even','custom') DEFAULT 'none',
  `tip_amount` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES
(1,1,1,1,240.00,0.00,0.00,0.00,240.00,'Cash & Cash','completed','2026-02-06 20:30:07','6','paid','Walk-in',240.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(2,1,1,1,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-06 20:59:35','6','paid','Walk-in',65.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(3,1,1,1,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-06 21:05:00','6','paid','Walk-in',65.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(4,1,1,1,120.00,0.00,0.00,0.00,15.00,'Cash & Card','completed','2026-02-06 21:05:40','6','paid','Walk-in',17.00,2.00,NULL,0.00,0.00,NULL,'none',0.00),
(5,5,1,1,45.00,0.00,0.00,0.00,40.50,'Cash','completed','2026-02-06 23:13:04',NULL,'paid','Jane Smith',40.50,0.00,2,0.00,0.00,NULL,'none',0.00),
(6,5,1,1,15.00,0.00,0.00,0.00,13.50,'Cash','completed','2026-02-06 23:15:54',NULL,'paid','Jane Smith',13.50,0.00,2,0.00,0.00,NULL,'none',0.00),
(7,1,1,1,0.00,0.00,0.00,0.00,0.00,'Cash','completed','2026-02-07 05:36:29',NULL,'paid','Jane Smith',0.00,0.00,2,0.00,0.00,NULL,'none',0.00),
(8,1,1,1,15.00,0.00,0.00,0.00,13.50,'Cash','completed','2026-02-07 05:36:55',NULL,'paid','Jane Smith',13.50,0.00,2,0.00,0.00,NULL,'none',0.00),
(9,1,1,1,65.00,0.00,0.00,0.00,58.50,'Cash','completed','2026-02-07 05:37:53','4','paid','John Doe',58.50,0.00,1,0.00,0.00,NULL,'none',0.00),
(10,1,1,1,65.00,0.00,0.00,0.00,65.00,'Cash & MTN Money','completed','2026-02-07 07:08:27','6','paid','Walk-in',70.00,5.00,NULL,0.00,0.00,NULL,'none',0.00),
(11,3,1,1,15.00,0.00,0.00,0.00,15.00,'Cash','completed','2026-02-07 08:18:05',NULL,'paid','Walk-in',25.00,10.00,NULL,0.00,0.00,NULL,'none',0.00),
(12,3,1,1,40.00,0.00,0.00,0.00,36.00,'Cash','completed','2026-02-07 08:19:45',NULL,'paid','John Doe',36.00,0.00,1,0.00,0.00,NULL,'none',0.00),
(13,3,1,1,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-07 08:20:07','6','paid','Walk-in',130.00,65.00,NULL,0.00,0.00,NULL,'none',0.00),
(14,3,1,1,50.00,0.00,0.00,0.00,50.00,'Cash','completed','2026-02-07 08:22:06',NULL,'paid','Walk-in',50.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(15,3,1,1,25.00,0.00,0.00,0.00,25.00,'Cash','completed','2026-02-07 08:22:44',NULL,'paid','daliso',25.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(16,3,1,3,15.00,0.00,0.00,0.00,13.50,'Cash','completed','2026-02-07 11:53:19','6','paid','Jane Smith',20.00,6.50,2,0.00,0.00,NULL,'none',0.00),
(17,3,1,3,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-07 12:04:46','6','paid','Walk-in',65.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(18,2,7,4,25.00,0.00,4.00,0.00,29.00,'card','completed','2026-02-09 06:52:07',NULL,'paid','Walk-in',0.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(21,1,1,5,80.00,0.00,0.00,0.00,80.00,'Cash','completed','2026-02-09 08:04:34','4','paid','Walk-in',80.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(22,1,1,17,55.00,0.00,0.00,0.00,55.00,'Card','completed','2026-02-09 19:18:24',NULL,'paid','Walk-in',55.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(23,1,1,17,75.00,0.00,0.00,0.00,75.00,'Card & Cash','completed','2026-02-09 19:32:15','4','paid','Walk-in',100.00,25.00,NULL,0.00,0.00,NULL,'none',0.00),
(24,1,1,17,80.00,0.00,0.00,0.00,80.00,'Cash','completed','2026-02-09 19:52:37','6','paid','Guest 1',80.00,0.00,NULL,0.00,0.00,'SPLIT-698a3b05e3aae','item',0.00),
(25,1,1,17,15.00,0.00,0.00,0.00,15.00,'Cash','completed','2026-02-09 19:52:37',NULL,'paid','Guest 2',15.00,0.00,NULL,0.00,0.00,'SPLIT-698a3b05e3aae','item',0.00),
(26,1,1,17,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-09 19:52:38','4','paid','Guest 3',65.00,0.00,NULL,0.00,0.00,'SPLIT-698a3b05e3aae','item',0.00),
(27,1,1,18,135.00,0.00,0.00,0.00,135.00,'Cash','completed','2026-02-09 19:54:42','6','paid','Guest 1',135.00,0.00,NULL,0.00,0.00,'SPLIT-698a3b82730c2','item',0.00),
(28,1,1,18,80.00,0.00,0.00,0.00,80.00,'Cash','completed','2026-02-09 19:54:42','3','paid','Guest 2',80.00,0.00,NULL,0.00,0.00,'SPLIT-698a3b82730c2','item',0.00),
(29,1,1,18,80.00,0.00,0.00,0.00,80.00,'Cash','completed','2026-02-09 19:54:42','4','paid','Guest 3',80.00,0.00,NULL,0.00,0.00,'SPLIT-698a3b82730c2','item',0.00),
(30,1,1,18,135.00,0.00,0.00,0.00,135.00,'Cash','completed','2026-02-09 20:08:33','3','paid','Guest 1',135.00,0.00,NULL,0.00,0.00,'SPLIT-698a3ec1e7e3f','item',0.00),
(31,1,1,18,80.00,0.00,0.00,0.00,80.00,'Cash','completed','2026-02-09 20:08:34','3','paid','Guest 2',80.00,0.00,NULL,0.00,0.00,'SPLIT-698a3ec1e7e3f','item',0.00),
(32,1,1,18,135.00,0.00,0.00,0.00,135.00,'Cash','completed','2026-02-09 20:08:34','6','paid','Guest 3',135.00,0.00,NULL,0.00,0.00,'SPLIT-698a3ec1e7e3f','item',0.00),
(33,1,1,18,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-09 20:10:04','6','paid','Walk-in',65.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(34,1,1,18,32.50,0.00,0.00,0.00,32.50,'Cash','completed','2026-02-09 20:18:19',NULL,'paid','Guest 1',32.50,0.00,NULL,0.00,0.00,'SPLIT-698a410bda0d1','even',0.00),
(35,1,1,18,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-09 20:18:19','6','paid','Guest 2',65.00,0.00,NULL,0.00,0.00,'SPLIT-698a410bda0d1','even',0.00),
(36,1,1,18,32.50,0.00,0.00,0.00,32.50,'Cash','completed','2026-02-09 20:20:23',NULL,'paid','Guest 1',32.50,0.00,NULL,0.00,0.00,'SPLIT-698a41875bbb5','even',0.00),
(37,1,1,18,32.50,0.00,0.00,0.00,32.50,'Cash','completed','2026-02-09 20:20:23',NULL,'paid','Guest 2',32.50,0.00,NULL,0.00,0.00,'SPLIT-698a41875bbb5','even',0.00),
(38,1,1,18,32.50,0.00,0.00,0.00,32.50,'Cash','completed','2026-02-09 20:21:56',NULL,'paid','Guest 1',32.50,0.00,NULL,0.00,0.00,'SPLIT-698a41e4d585d','even',0.00),
(39,1,1,18,32.50,0.00,0.00,0.00,32.50,'Cash','completed','2026-02-09 20:21:56',NULL,'paid','Guest 2',32.50,0.00,NULL,0.00,0.00,'SPLIT-698a41e4d585d','even',0.00),
(40,1,1,18,43.33,0.00,0.00,0.00,43.33,'Cash','completed','2026-02-09 20:34:11',NULL,'paid','Guest 1',43.33,0.00,NULL,0.00,0.00,'SPLIT-698a44c3714e7','even',0.00),
(41,1,1,18,43.33,0.00,0.00,0.00,43.33,'Cash','completed','2026-02-09 20:34:11',NULL,'paid','Guest 2',43.33,0.00,NULL,0.00,0.00,'SPLIT-698a44c3714e7','even',0.00),
(42,1,1,18,43.33,0.00,0.00,0.00,43.33,'Cash','completed','2026-02-09 20:34:11',NULL,'paid','Guest 3',43.33,0.00,NULL,0.00,0.00,'SPLIT-698a44c3714e7','even',0.00),
(43,1,1,18,22.50,0.00,0.00,0.00,22.50,'Cash','completed','2026-02-09 20:50:25',NULL,'paid','Guest 1',22.50,0.00,NULL,0.00,0.00,'SPLIT-698a489146a97','even',0.00),
(44,1,1,18,22.50,0.00,0.00,0.00,22.50,'Cash','completed','2026-02-09 20:50:25',NULL,'paid','Guest 2',22.50,0.00,NULL,0.00,0.00,'SPLIT-698a489146a97','even',0.00),
(45,1,1,18,22.50,0.00,0.00,0.00,22.50,'Cash','completed','2026-02-09 21:07:13',NULL,'paid','Guest 1',22.50,0.00,NULL,0.00,0.00,'SPLIT-698a4c8175213','even',0.00),
(46,1,1,18,22.50,0.00,0.00,0.00,22.50,'Cash','completed','2026-02-09 21:07:13',NULL,'paid','Guest 2',22.50,0.00,NULL,0.00,0.00,'SPLIT-698a4c8175213','even',0.00),
(47,1,1,18,15.00,0.00,0.00,0.00,15.00,'Card','completed','2026-02-09 21:10:17',NULL,'paid','Guest 1',15.00,0.00,NULL,0.00,0.00,'SPLIT-698a4d39db0ee','item',0.00),
(49,1,1,18,15.00,0.00,0.00,0.00,15.00,'Cash','completed','2026-02-09 21:16:59',NULL,'paid','Walk-in',15.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(50,1,1,18,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-09 21:17:20','6','paid','Walk-in',65.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(51,1,1,19,7.50,0.00,0.00,0.00,7.50,'Cash','completed','2026-02-09 21:40:10',NULL,'paid','Guest 1',7.50,0.00,NULL,0.00,0.00,'SPLIT-698a543af102e','even',0.00),
(52,1,1,19,7.50,0.00,0.00,0.00,7.50,'Cash','completed','2026-02-09 21:40:10',NULL,'paid','Guest 2',7.50,0.00,NULL,0.00,0.00,'SPLIT-698a543af102e','even',0.00),
(54,1,1,19,80.00,0.00,0.00,0.00,80.00,'Cash','completed','2026-02-09 22:11:24','3','paid','Walk-in',80.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(55,1,1,19,15.00,0.00,0.00,0.00,15.00,'Cash','completed','2026-02-09 22:38:51',NULL,'paid','Walk-in',20.00,2.75,NULL,0.00,0.00,NULL,'none',2.25),
(56,1,1,19,145.00,0.00,0.00,0.00,145.00,'Cash','completed','2026-02-09 22:48:52','4','paid','Walk-in',200.00,40.50,NULL,0.00,0.00,NULL,'none',14.50),
(57,1,1,19,200.00,0.00,0.00,0.00,200.00,'Cash','completed','2026-02-09 22:57:29','6','paid','Walk-in',220.00,0.00,NULL,0.00,0.00,NULL,'none',20.00),
(58,1,1,19,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-09 22:58:01','4','paid','Walk-in',68.25,0.00,NULL,0.00,0.00,NULL,'none',3.25),
(59,1,1,19,120.00,0.00,0.00,0.00,120.00,'Cash','completed','2026-02-09 22:58:48','4','paid','Walk-in',126.00,0.00,NULL,0.00,0.00,NULL,'none',6.00),
(60,1,1,19,65.00,0.00,0.00,0.00,65.00,'Cash','completed','2026-02-09 23:27:07','4','refunded','Walk-in',70.00,5.00,NULL,0.00,0.00,NULL,'none',0.00),
(61,1,1,19,130.00,0.00,0.00,0.00,130.00,'Cash','completed','2026-02-09 23:27:47','6','refunded','Walk-in',150.00,13.50,NULL,0.00,0.00,NULL,'none',6.50),
(62,1,1,19,120.00,0.00,0.00,0.00,120.00,'Cash','completed','2026-02-09 23:35:29','3','refunded','Walk-in',150.00,12.00,NULL,0.00,0.00,NULL,'none',18.00),
(63,1,1,20,120.00,0.00,0.00,0.00,120.00,'Cash','completed','2026-02-10 00:04:44','3','paid','Walk-in',150.00,18.00,NULL,0.00,0.00,NULL,'none',12.00),
(64,1,1,20,120.00,0.00,0.00,0.00,120.00,'Cash','completed','2026-02-10 00:32:45','4','paid','Walk-in',200.00,68.00,NULL,0.00,0.00,NULL,'none',12.00),
(65,2,4,21,25.00,0.00,0.00,0.00,25.00,'Cash','completed','2026-02-10 10:32:02',NULL,'paid','Walk-in',25.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(66,2,4,21,25.00,0.00,0.00,0.00,25.00,'Cash','completed','2026-02-10 10:33:12',NULL,'paid','Walk-in',25.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(67,2,4,21,100.00,0.00,0.00,0.00,100.00,'Cash','completed','2026-02-10 10:33:27',NULL,'paid','Walk-in',100.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(68,2,4,21,105.00,0.00,0.00,0.00,105.00,'Cash','completed','2026-02-10 10:34:14',NULL,'paid','Walk-in',105.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(69,2,3,0,105.00,0.00,0.00,0.00,105.00,'Cash','completed','2026-02-10 12:17:42',NULL,'paid','Walk-in',105.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(70,2,3,0,75.00,0.00,0.00,0.00,75.00,'Cash','completed','2026-02-10 12:28:00',NULL,'paid','Walk-in',75.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(71,2,3,0,135.00,0.00,0.00,0.00,135.00,'Cash','completed','2026-02-10 12:33:10',NULL,'paid','Walk-in',135.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(72,2,3,0,40.00,0.00,0.00,0.00,40.00,'Cash','completed','2026-02-10 12:39:34',NULL,'paid','Walk-in',40.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(73,2,3,0,45.00,0.00,0.00,0.00,45.00,'Cash','completed','2026-02-10 13:08:41',NULL,'paid','Walk-in',45.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(74,2,1,0,90.00,0.00,0.00,0.00,90.00,'Cash','completed','2026-02-10 16:11:57',NULL,'paid','Walk-in',90.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(75,2,1,0,90.00,0.00,0.00,0.00,90.00,'Cash','completed','2026-02-10 16:20:14',NULL,'paid','Walk-in',90.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(76,2,1,0,15.00,0.00,0.00,0.00,15.00,'Cash','completed','2026-02-10 16:27:06',NULL,'paid','Walk-in',15.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(77,2,1,0,45.00,0.00,0.00,0.00,45.00,'MTN Money','completed','2026-02-10 16:35:33',NULL,'paid','mando',100.00,55.00,NULL,0.00,0.00,NULL,'none',0.00),
(78,2,1,0,15.00,0.00,0.00,0.00,15.00,'Cash','completed','2026-02-10 16:37:41',NULL,'paid','mando 2',15.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(79,2,1,0,70.00,0.00,0.00,0.00,70.00,'Cash','completed','2026-02-10 16:46:19',NULL,'paid','',70.00,0.00,NULL,0.00,0.00,NULL,'none',0.00),
(80,2,1,0,85.00,0.00,0.00,0.00,85.00,'Cash','completed','2026-02-10 16:48:40',NULL,'paid','table 1',100.00,15.00,NULL,0.00,0.00,NULL,'none',0.00);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shifts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `location_id` int NOT NULL,
  `start_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NULL DEFAULT NULL,
  `starting_cash` decimal(10,2) DEFAULT '0.00',
  `closing_cash` decimal(10,2) DEFAULT '0.00',
  `expected_cash` decimal(10,2) DEFAULT '0.00',
  `manager_closing_cash` decimal(10,2) DEFAULT '0.00',
  `status` enum('pending_approval','open','closed') DEFAULT 'pending_approval',
  `variance_reason` text,
  `handover_notes` text,
  `start_verified_by` int DEFAULT NULL,
  `start_verified_at` timestamp NULL DEFAULT NULL,
  `end_verified_by` int DEFAULT NULL,
  `end_verified_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  KEY `start_verified_by` (`start_verified_by`),
  KEY `end_verified_by` (`end_verified_by`),
  CONSTRAINT `shifts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `shifts_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `shifts_ibfk_3` FOREIGN KEY (`start_verified_by`) REFERENCES `users` (`id`),
  CONSTRAINT `shifts_ibfk_4` FOREIGN KEY (`end_verified_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
INSERT INTO `shifts` VALUES
(1,1,5,'2026-02-06 20:03:34','2026-02-09 06:21:02',700.00,1467.00,1467.00,0.00,'closed','',NULL,1,'2026-02-06 20:03:38',1,'2026-02-09 06:21:02'),
(2,1,1,'2026-02-07 08:43:17','2026-02-09 06:20:48',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-07 08:43:22',1,'2026-02-09 06:20:48'),
(3,1,2,'2026-02-07 08:46:59','2026-02-07 12:42:49',0.00,50.00,78.50,0.00,'closed','lost',NULL,1,'2026-02-07 08:47:03',1,'2026-02-07 12:42:49'),
(4,7,2,'2026-02-09 06:51:18','2026-02-09 15:10:09',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 06:51:18',1,'2026-02-09 15:10:09'),
(5,1,1,'2026-02-09 07:39:19','2026-02-09 09:02:37',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 07:39:19',1,'2026-02-09 09:02:37'),
(6,1,1,'2026-02-09 09:02:48','2026-02-09 09:02:59',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 09:02:53',1,'2026-02-09 09:02:59'),
(7,1,4,'2026-02-09 15:08:22','2026-02-09 15:08:39',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 15:08:24',1,'2026-02-09 15:08:39'),
(8,7,4,'2026-02-09 15:10:37','2026-02-09 15:10:48',0.00,0.00,0.00,0.00,'closed','',NULL,1,'2026-02-09 15:10:41',1,'2026-02-09 15:10:48'),
(9,1,4,'2026-02-09 15:20:24','2026-02-09 15:20:40',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 15:20:30',1,'2026-02-09 15:20:40'),
(10,1,4,'2026-02-09 15:21:04','2026-02-09 15:39:29',5.00,5.00,5.00,0.00,'closed','',NULL,1,'2026-02-09 15:21:07',1,'2026-02-09 15:39:29'),
(11,7,4,'2026-02-09 15:22:52','2026-02-09 16:02:41',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 15:22:56',1,'2026-02-09 16:02:41'),
(12,1,4,'2026-02-09 15:39:37','2026-02-09 15:39:52',5.00,5.00,5.00,0.00,'closed','',NULL,1,'2026-02-09 15:39:39',1,'2026-02-09 15:39:52'),
(13,1,4,'2026-02-09 15:54:25','2026-02-09 16:04:23',300.00,300.00,300.00,0.00,'closed','',NULL,1,'2026-02-09 15:54:28',1,'2026-02-09 16:04:23'),
(14,7,4,'2026-02-09 16:02:52','2026-02-09 16:03:58',6.00,6.00,6.00,0.00,'closed','',NULL,1,'2026-02-09 16:02:56',1,'2026-02-09 16:03:58'),
(15,1,4,'2026-02-09 16:04:44','2026-02-09 16:06:59',0.00,0.00,0.00,0.00,'closed','',NULL,1,'2026-02-09 16:04:47',1,'2026-02-09 16:06:59'),
(16,7,4,'2026-02-09 16:07:32','2026-02-09 16:11:16',5.00,5.00,5.00,0.00,'closed','',NULL,1,'2026-02-09 16:07:36',1,'2026-02-09 16:11:16'),
(17,1,1,'2026-02-09 16:11:38','2026-02-09 19:53:13',500.00,735.00,735.00,0.00,'closed','',NULL,1,'2026-02-09 16:11:41',1,'2026-02-09 19:53:13'),
(18,1,1,'2026-02-09 19:53:25','2026-02-09 21:39:21',0.00,1157.49,1157.49,0.00,'closed','',NULL,1,'2026-02-09 19:53:27',1,'2026-02-09 21:39:21'),
(19,1,1,'2026-02-09 21:39:51','2026-02-09 23:38:19',0.00,835.00,835.00,0.00,'closed','',NULL,1,'2026-02-09 21:39:53',1,'2026-02-09 23:38:19'),
(20,1,1,'2026-02-09 23:39:18','2026-02-10 00:36:01',0.00,240.00,240.00,0.00,'closed','',NULL,1,'2026-02-09 23:39:20',1,'2026-02-10 00:36:01'),
(21,4,2,'2026-02-10 10:26:31',NULL,0.00,0.00,0.00,0.00,'open',NULL,NULL,3,'2026-02-10 10:26:37',NULL,NULL),
(22,3,2,'2026-02-10 11:35:23',NULL,0.00,0.00,0.00,0.00,'open',NULL,NULL,3,'2026-02-10 11:35:25',NULL,NULL),
(23,1,2,'2026-02-10 16:11:13',NULL,0.00,0.00,0.00,0.00,'open',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfer_items`
--

DROP TABLE IF EXISTS `stock_transfer_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfer_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transfer_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity_requested` decimal(10,2) NOT NULL,
  `quantity_sent` decimal(10,2) DEFAULT '0.00',
  `quantity_received` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `stock_transfer_items_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `stock_transfers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_transfer_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfer_items`
--

LOCK TABLES `stock_transfer_items` WRITE;
/*!40000 ALTER TABLE `stock_transfer_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfer_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfers`
--

DROP TABLE IF EXISTS `stock_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `source_location_id` int NOT NULL,
  `destination_location_id` int NOT NULL,
  `user_id` int NOT NULL,
  `status` enum('pending','completed','cancelled','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `source_location_id` (`source_location_id`),
  KEY `destination_location_id` (`destination_location_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `stock_transfers_ibfk_1` FOREIGN KEY (`source_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `stock_transfers_ibfk_2` FOREIGN KEY (`destination_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `stock_transfers_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfers`
--

LOCK TABLES `stock_transfers` WRITE;
/*!40000 ALTER TABLE `stock_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `rate` decimal(5,2) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
INSERT INTO `taxes` VALUES
(1,'VAT',16.00,1),
(2,'Service Charge',10.00,0);
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `from_location_id` int NOT NULL,
  `to_location_id` int NOT NULL,
  `quantity` int NOT NULL,
  `status` enum('pending','completed') DEFAULT 'completed',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `from_location_id` (`from_location_id`),
  KEY `to_location_id` (`to_location_id`),
  CONSTRAINT `transfers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `transfers_ibfk_2` FOREIGN KEY (`from_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `transfers_ibfk_3` FOREIGN KEY (`to_location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','shopkeeper','manager','cashier','dev','chef','waiter','head_chef','bartender') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'cashier',
  `location_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `force_password_change` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','System Admin','$2y$10$AJ1DKDKmwF3BHFNYpQUgwOTwbzuUCXH04KMXRykW.chnVaFT2NIfu','admin',3,'2026-02-06 19:59:35',0,1),
(2,'mando','mando chishimba','$2y$10$f7zbSGxQ7gvsH5N1dEOLauAgZS3dO1cV/8Gj.UNOmK6Z2a0JxWBbu','dev',3,'2026-02-06 19:59:35',0,1),
(3,'manager','Manager','$2y$10$3owGZE25FfMAUBAFy9oL7OwSu6atNLFJZW7uwH7DG8k.RC71DWnLq','manager',2,'2026-02-06 19:59:35',0,1),
(4,'main_bar','Main Bar','$2y$10$rt3.rImohXcDiq/J4HikCOQJp..byFlP4zaFxvLCRgZBVoW9R6TOi','cashier',2,'2026-02-06 19:59:35',0,1),
(5,'head_chef','Head Chef','$2y$10$oC8.PLHRf618Hx3vHSBMHusOiRFb9m82/mnRg3zYyOJ9eKLZh/CRi','manager',1,'2026-02-06 19:59:35',0,1),
(6,'waiter','Restaurant Waiter','$2y$10$44N80Jh9tzg6KlcvyXoj..2pjF705XsJjsU/TinTWdEW3BPKBq9ni','cashier',4,'2026-02-06 19:59:35',0,1),
(7,'bartender','Main Bartender','$2y$10$AJ1DKDKmwF3BHFNYpQUgwOTwbzuUCXH04KMXRykW.chnVaFT2NIfu','bartender',2,'2026-02-06 19:59:35',0,0),
(8,'chef','chef','$2y$10$M9vANzbl70OlafoGFIn/b.0Kyhl6JuQi21i5d6tjcBWnV8RxtjOZ2','cashier',NULL,'2026-02-10 08:21:50',0,1),
(9,'Res_Bar','Restaurant Bar','$2y$10$kgBG5wcxk3KB1/37QJU3ZuTxGkwD8PAzVha11irdvuY.N.IdrZaD2','cashier',NULL,'2026-02-10 09:53:29',0,1),
(10,'daliso','Daliso Nindi','$2y$10$0Cmqbbba.ipH/7x1fh9QOuQ8z4FayAfR1TuvXhzShncyprrq27Z4.','admin',NULL,'2026-02-10 10:20:55',0,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors`
--

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` VALUES
(1,'Coca Cola Zambia','Mr. Phiri',NULL,1),
(2,'Zambeef','Sales Rep',NULL,1),
(3,'Tiger Animal Feeds','Mrs. Banda',NULL,1),
(4,'Shoprite','Maybin','12345678',1);
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-12  2:00:00
